

cd "%~dp0"

 start java -jar userimport-2.1.1-all.jar groups.csv
 start java -jar userimport-2.1.1-all.jar datasource.csv